# Deep-Learning-Specialization
Deeplearning.ai
notes of Deep learning course by Andrew NG.
